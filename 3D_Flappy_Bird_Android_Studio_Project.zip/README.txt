3D Flappy Bird — Android wrapper project

This is an Android Studio project for an app named "3D Flappy Bird", with a custom launcher icon. It opens the published game at:
https://flap-3d-na6tpu.v2.appdeploy.ai/

Important: this ZIP is the Android project source, not a compiled APK. An Android SDK/Gradle build environment is required to compile the APK.

Build an APK:
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Android Studio > Open > select the extracted "3d_flappy_bird_android" folder.
4. Allow Gradle sync and install any SDK components Android Studio requests.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When complete, click "locate" in the notification. The debug APK is normally at app/build/outputs/apk/debug/app-debug.apk.
7. Transfer the APK to your Android phone and install it. You may need to allow installation from that file manager.

The app requires an internet connection because the game is loaded from the published website. It is not an offline bundle.
